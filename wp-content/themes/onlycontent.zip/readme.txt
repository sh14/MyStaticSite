=== contentonly ===
Contributors: sh14ru
Tags: custom-logo, one-column, translation-ready, clear
Requires at least: 4.9
Tested up to: 4.9.8
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==
Ultra-minimal theme for using with page-builder plugins.

== Changelog ==

= 1.0 =
* Theme creates

== Upgrade Notice ==

= 1.0 =
* No upgrades yet.

= 1.0.0 =
* 13-Jun-2020
* Initial release
